const OtherCourses = {
	courses : [
		{ subject: "Science", number: 1, title: "Part I of science sequence (biology, chemistry, or physics)" },
		{ subject: "Science", number: 2, title: "Part II of science sequence (biology, chemistry, or physics)" },
		{ subject: "MATH", number: 224, title: "Differential/Integral Calculus (Calculus I)" },
		{ subject: "MATH", number: 226, title: "Integration Techniques and Application/Infinite Series (Calculus II)" },
		{ subject: "MATH", number: 314, title: "Discrete Mathematics/Number Systems" },
		{ subject: "MATH", number: 327, title: "Probability with Statistical Methods (or MATH448 Mathematical Statistics)" },
		{ subject: "MATH", number: '', title: "Math Elective (MATH304 Linear Algebra, MATH371 Ordinary Differential Equations, MATH381 Graph Theory, MATH386 Combinatorics, or MATH407 Introduction to the Theory of Numbers)" },
	]
}

export default OtherCourses;
